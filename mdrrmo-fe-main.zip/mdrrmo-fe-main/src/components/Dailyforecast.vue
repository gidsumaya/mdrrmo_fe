<template>
  <div class="card is-hidden1">
        <div class="card-header"><p class="card-header-title">Daily Forecast</p></div>
        <div class="card-content"><div class="content">Content</div></div>
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>