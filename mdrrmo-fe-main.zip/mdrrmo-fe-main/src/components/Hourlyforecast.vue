<template>
  <div class="card is-hidden1">
        <div class="card-header"><p class="card-header-title">Hourly Forecast</p></div>
        <div class="card-content">
            
        </div>
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>