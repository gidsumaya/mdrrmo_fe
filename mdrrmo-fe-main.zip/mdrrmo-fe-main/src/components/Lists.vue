<template>

<div class="section">

    <div class="card">
        <div class="card-header">
            <p class="card-header-title">Rainfall Activities</p>
        </div>
        <div class="card-content">
        
        <div class="content">Content</div>
        </div>
    </div>


    <!-- <div class="card is-hidden1">
        <div class="card-header"><p class="card-header-title">Export</p></div>
        <div class="card-content">
        <div class="content"><button class="button is-fullwidth">Current Month</button></div>
        <div class="content"><button class="button is-fullwidth">Last Month</button></div>
        <div class="content"><button class="button is-fullwidth">Current Year</button></div>
        <div class="content"><button class="button is-fullwidth">Last Year</button></div>
        </div>
    </div> -->
</div>
</template>

<script>
export default {

}
</script>

<style>

</style>